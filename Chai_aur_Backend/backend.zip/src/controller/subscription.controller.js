import mongoose, { isValidObjectId } from "mongoose"
import { User } from "../models/user.model.js"
import { Subscription } from "../models/subscription.model.js"
import { ApiError } from "../utils/ApiError.js"
import { ApiResponse } from "../utils/ApiResponse.js"
import { asyncHandler } from "../utils/asyncHandler.js"

// ---------------------------------------------------
// Toggle Subscription (Subscribe / Unsubscribe)
// ---------------------------------------------------
const toggleSubscription = asyncHandler(async (req, res) => {
    const { channelId } = req.params

    if (!isValidObjectId(channelId)) {
        throw new ApiError(400, "Invalid channel ID")
    }

    const channel = await User.findById(channelId)
    if (!channel) {
        throw new ApiError(404, "Channel not found")
    }

    const existingSubscription = await Subscription.findOne({
        subscriber: req.user._id,
        channel: channelId
    })

    // Unsubscribe
    if (existingSubscription) {
        await Subscription.findByIdAndDelete(existingSubscription._id)

        return res.status(200).json(
            new ApiResponse(200, {}, "Unsubscribed successfully")
        )
    }

    // Subscribe
    const newSubscription = await Subscription.create({
        subscriber: req.user._id,
        channel: channelId
    })

    return res.status(201).json(
        new ApiResponse(201, newSubscription, "Subscribed successfully")
    )
})

// ---------------------------------------------------
// Get All Subscribers of a Channel
// ---------------------------------------------------
const getUserChannelSubscribers = asyncHandler(async (req, res) => {
    const { channelId } = req.params

    if (!isValidObjectId(channelId)) {
        throw new ApiError(400, "Invalid channel ID")
    }

    const channel = await User.findById(channelId)
    if (!channel) throw new ApiError(404, "Channel not found")

    const subscribers = await Subscription.find({ channel: channelId })
        .populate("subscriber", "username fullName avatar email")

    return res.status(200).json(
        new ApiResponse(200, subscribers, "Channel subscribers fetched successfully")
    )
})

// ---------------------------------------------------
// Get All Channels that a User has Subscribed to
// ---------------------------------------------------
const getSubscribedChannels = asyncHandler(async (req, res) => {
    const { subscriberId } = req.params

    if (!isValidObjectId(subscriberId)) {
        throw new ApiError(400, "Invalid subscriber ID")
    }

    const user = await User.findById(subscriberId)
    if (!user) throw new ApiError(404, "User not found")

    const subscribedChannels = await Subscription.find({ subscriber: subscriberId })
        .populate("channel", "username fullName avatar email")

    return res.status(200).json(
        new ApiResponse(200, subscribedChannels, "Subscribed channels fetched successfully")
    )
})

export {
    toggleSubscription,
    getUserChannelSubscribers,
    getSubscribedChannels
}
