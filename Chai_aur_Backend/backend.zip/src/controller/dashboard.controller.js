import mongoose from "mongoose"
import { Video } from "../models/video.model.js"
import { Subscription } from "../models/subscription.model.js"
import { Like } from "../models/like.model.js"
import { ApiError } from "../utils/ApiError.js"
import { ApiResponse } from "../utils/ApiResponse.js"
import { asyncHandler } from "../utils/asyncHandler.js"


// --------------------------------------------------------
// 📌 1. Get Channel Stats
// --------------------------------------------------------
const getChannelStats = asyncHandler(async (req, res) => {
    const channelId = req.user?._id;  // logged-in user's channel

    if (!channelId) {
        throw new ApiError(400, "Channel ID not found")
    }

    // ---------------------------
    // 🟦 Total Videos
    // ---------------------------
    const totalVideos = await Video.countDocuments({ owner: channelId });

    // ---------------------------
    // 🟥 Total Subscribers
    // ---------------------------
    const totalSubscribers = await Subscription.countDocuments({
        channel: channelId
    });

    // ---------------------------
    // 🟩 Total Likes on all channel videos
    // ---------------------------
    const totalLikes = await Like.countDocuments({
        video: { $exists: true },
        owner: channelId
    });

    // ---------------------------
    // 🟨 Total Views of all videos
    // ---------------------------
    const videoViews = await Video.aggregate([
        { $match: { owner: new mongoose.Types.ObjectId(channelId) } },
        {
            $group: {
                _id: null,
                totalViews: { $sum: "$views" }
            }
        }
    ]);

    const totalViews = videoViews[0]?.totalViews || 0;

    return res.status(200).json(
        new ApiResponse(
            200,
            {
                totalVideos,
                totalSubscribers,
                totalLikes,
                totalViews
            },
            "Channel stats fetched successfully"
        )
    );
});


// --------------------------------------------------------
// 📌 2. Get All Videos Uploaded by Channel
// --------------------------------------------------------
const getChannelVideos = asyncHandler(async (req, res) => {
    const channelId = req.user?._id;

    if (!channelId) {
        throw new ApiError(400, "Channel ID not found");
    }

    const videos = await Video.find({ owner: channelId }).sort({ createdAt: -1 });

    return res.status(200).json(
        new ApiResponse(
            200,
            videos,
            "Channel videos fetched successfully"
        )
    );
});


export {
    getChannelStats,
    getChannelVideos
}
